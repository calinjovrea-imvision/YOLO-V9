# import requests
# import glob
# from PIL import Image
# import numpy as np

# # Get the list of image files
# images = glob.glob('/root/servers/IMV_SEMANTIC_SEARCH_YOLO_SERVER/INDEX/index_hetz4/output/INDEX/hetz1_index/video/POE-Selina-Cetate-2-20240926171425-20240926171642/*.jpg')
# print(images)

# # URL to send the POST request
# # model_url_1 = 'http://127.0.0.1:5000/infer'
# # model_url_2 = 'http://127.0.0.1:5001/infer'
# # model_url_3 = 'http://127.0.0.1:5002/infer'
# # model_url_4 = 'http://127.0.0.1:5003/infer'
# # model_url_5 = 'http://127.0.0.1:5004/infer'
# # model_url_6 = 'http://127.0.0.1:5005/infer'
# model_url_7 = 'http://127.0.0.1:5006/infer'
# model_url_8 = 'http://127.0.0.1:5007/infer'
# model_url_9 = 'http://127.0.0.1:5008/infer'
# model_url_0 = 'http://127.0.0.1:5009/infer'

# send_images = []
# count = 0
# # Read, process, and send each image
# for image_path in images:
#     try:
#         count += 1
#         with Image.open(image_path) as img:
            
#             img = img.convert('RGB')  # Ensure 3 channels (RGB)
#             img = img.resize((640, 640))  # Only width & height

#             # Convert the image to a NumPy array
#             img_array = np.array(img)  # Shape: (640, 640, 3)

#             # Permute dimensions to (3, 640, 640)
#             img_array = np.transpose(img_array, (2, 0, 1))  # Channels first
            
#             # response = requests.post(model_url_1, json={'inputs': img_array.tolist()})
#             # response = requests.post(model_url_2, json={'inputs': img_array.tolist()})
#             response = requests.post(model_url_7, json={'inputs': img_array.tolist()})

#             # Handle the response
#             if response.status_code == 200:
#                 print(f"Success for {send_images}: {response.json()}")
#             else:
#                 print(f"Failed for {send_images}: {response.status_code}, {response.text}")
#             # response = requests.post(model_url_7, json={'inputs': img_array.tolist()})
#             # response = requests.post(model_url_7, json={'inputs': img_array.tolist()})

#             response = requests.post(model_url_8, json={'inputs': img_array.tolist()})

#             # Handle the response
#             if response.status_code == 200:
#                 print(f"Success for {send_images}: {response.json()}")
#             else:
#                 print(f"Failed for {send_images}: {response.status_code}, {response.text}")
#             response = requests.post(model_url_9, json={'inputs': img_array.tolist()})

#             # Handle the response
#             if response.status_code == 200:
#                 print(f"Success for {send_images}: {response.json()}")
#             else:
#                 print(f"Failed for {send_images}: {response.status_code}, {response.text}")
#             response = requests.post(model_url_0, json={'inputs': img_array.tolist()})

#             # Handle the response
#             if response.status_code == 200:
#                 print(f"Success for {send_images}: {response.json()}")
#             else:
#                 print(f"Failed for {send_images}: {response.status_code}, {response.text}")
#             # response = requests.post(model_url_4, json={'inputs': img_array.tolist()})
#             # response = requests.post(model_url_5, json={'inputs': img_array.tolist()})

#             # Handle the response
#             # if response.status_code == 200:
#             #     print(f"Success for {send_images}: {response.json()}")
#             # else:
#             #     print(f"Failed for {send_images}: {response.status_code}, {response.text}")

#         if count == 2:
#             break
#     except Exception as e:
#         print(f"Error processing {image_path}: {e}")

# # print(image_path)
# # Send the POST request with the image array as JSON


import glob
from PIL import Image
import numpy as np
import asyncio
import aiohttp

# List of API endpoints
model_urls = [
    'http://127.0.0.1:5011/infer',
    'http://127.0.0.1:5021/infer',
    'http://127.0.0.1:5031/infer',
    'http://127.0.0.1:5041/infer',
    'http://127.0.0.1:5051/infer',
    # 'http://127.0.0.1:5061/infer',
    # 'http://127.0.0.1:5071/infer',
    # 'http://127.0.0.1:5081/infer',
    # 'http://127.0.0.1:5091/infer',
    # 'http://127.0.0.1:5101/infer',
    # 'http://127.0.0.1:5111/infer',
    # 'http://127.0.0.1:5121/infer',
    # 'http://127.0.0.1:5131/infer',
    # 'http://127.0.0.1:5141/infer',
    # 'http://127.0.0.1:5151/infer',
    # 'http://127.0.0.1:5161/infer',
    # 'http://127.0.0.1:5171/infer',
    # 'http://127.0.0.1:5181/infer',
    # 'http://127.0.0.1:5191/infer',
    # 'http://127.0.0.1:5201/infer'
]

# Get image files
images = glob.glob('/root/servers/IMV_SEMANTIC_SEARCH_YOLO_SERVER/INDEX/index_hetz4/output/INDEX/hetz1_index/video/POE-Selina-Cetate-2-20240926171425-20240926171642/*.jpg')


async def send_image(session, url, img_array):
    """Send image data to the API asynchronously."""
    try:
        async with session.post(url, json={'inputs': img_array.tolist()}) as response:
            if response.status == 200:
                data = await response.json()
                print(f"Success for {url}: {data}")
            else:
                print(f"Failed for {url}: {response.status}, {await response.text()}")
    except Exception as e:
        print(f"Error sending to {url}: {e}")


async def process_image(image_path):
    """Process each image and send it to all servers."""
    try:
        with Image.open(image_path) as img:
            img = img.convert('RGB')
            img = img.resize((640, 640))
            img_array = np.transpose(np.array(img), (2, 0, 1))  # Shape: (3, 640, 640)

            async with aiohttp.ClientSession() as session:
                tasks = [send_image(session, url, img_array) for url in model_urls]
                await asyncio.gather(*tasks)  # Run all requests in parallel
    except Exception as e:
        print(f"Error processing {image_path}: {e}")


async def main():
    tasks = [process_image(image_path) for image_path in images[:200]]  # Limit to first 2 images
    await asyncio.gather(*tasks)


if __name__ == '__main__':
    asyncio.run(main())
