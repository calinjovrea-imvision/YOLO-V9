for PORT in {5010..5050..10}
do
    PORT=$PORT nohup gunicorn -w 1 -k examples.app.ScriptWorker 'examples.script:app' --bind 0.0.0.0:$PORT > log_$PORT.out 2>&1 &
    echo "Started server on port $PORT"
done