# worker.py
from gunicorn.workers.base import Worker
import time
import subprocess

class ScriptWorker(Worker):
    def run(self):
        subprocess.run(['nohup','python', '-m', 'examples.script', '>', 'log_$PORT.out', '2>&1', '&'])
        time.sleep(1)



