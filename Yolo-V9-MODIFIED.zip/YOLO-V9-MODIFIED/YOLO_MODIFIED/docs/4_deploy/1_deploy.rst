.. _Deploy:

Deploy Model
============

Deploy YOLOv9
-------------

Deploy YOLOv7
-------------
