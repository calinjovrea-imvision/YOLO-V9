Loss Function
=============
