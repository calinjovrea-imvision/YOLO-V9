Model
=====

Modified Architecture
---------------------





Modified Model Module
---------------------
